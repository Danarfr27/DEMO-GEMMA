package com.example.data.repository

import com.example.data.database.*
import kotlinx.coroutines.flow.Flow

class AssistantRepository(private val dao: AssistantDao) {
    val allChats: Flow<List<ChatHistoryEntity>> = dao.getAllChat()
    val allNotes: Flow<List<NoteEntity>> = dao.getAllNotes()
    val allReminders: Flow<List<ReminderEntity>> = dao.getAllReminders()
    val allMemory: Flow<List<UserMemoryEntity>> = dao.getAllMemory()
    val allHabits: Flow<List<HabitEntity>> = dao.getAllHabits()

    suspend fun insertChat(chat: ChatHistoryEntity) {
        dao.insertChat(chat)
    }

    suspend fun clearChat() {
        dao.clearChat()
    }

    suspend fun insertNote(note: NoteEntity) {
        dao.insertNote(note)
    }

    suspend fun deleteNoteById(id: Int) {
        dao.deleteNoteById(id)
    }

    suspend fun insertReminder(reminder: ReminderEntity) {
        dao.insertReminder(reminder)
    }

    suspend fun updateReminder(reminder: ReminderEntity) {
        dao.updateReminder(reminder)
    }

    suspend fun deleteReminderById(id: Int) {
        dao.deleteReminderById(id)
    }

    suspend fun getMemoryByKey(key: String): UserMemoryEntity? {
        return dao.getMemoryByKey(key)
    }

    suspend fun insertMemory(key: String, value: String) {
        dao.insertMemory(UserMemoryEntity(key = key, value = value))
    }

    suspend fun deleteMemoryByKey(key: String) {
        dao.deleteMemoryByKey(key)
    }

    suspend fun clearMemory() {
        dao.clearMemory()
    }

    suspend fun insertHabit(habit: HabitEntity) {
        dao.insertHabit(habit)
    }

    suspend fun deleteHabitById(id: Int) {
        dao.deleteHabitById(id)
    }
}
