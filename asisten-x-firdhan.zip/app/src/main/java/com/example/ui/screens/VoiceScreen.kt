package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AssistantViewModel

@Composable
fun VoiceScreen(viewModel: AssistantViewModel) {
    val isVoiceActive by viewModel.isVoiceActive.collectAsState()
    val speechText by viewModel.speechText.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val isAudioPermissionGranted by viewModel.isAudioPermissionGranted.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current

    // Launcher to request permission
    val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        viewModel.checkAudioPermission()
    }

    // Refresh permission and automatically start voice assistant when entering screen
    LaunchedEffect(isAudioPermissionGranted) {
        viewModel.checkAudioPermission()
        if (isAudioPermissionGranted) {
            viewModel.autoStartVoice()
        }
    }

    // Animation for glowing waves
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    if (!isAudioPermissionGranted) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .testTag("permission_fallback_screen")
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE53935).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = "Microphone Off",
                    tint = Color(0xFFE53935),
                    modifier = Modifier.size(48.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "IZIN MIKROFON DIBUTUHKAN",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                color = Color(0xFFE53935)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Mode Suara Asisten membutuhkan izin merekam audio agar asisten pintar Anda dapat mendengar dan melayani perintah suara Anda secara instan.",
                fontSize = 14.sp,
                lineHeight = 22.sp,
                color = MaterialTheme.colorScheme.outline,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = {
                    permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                    // Check if already denied so we directly assist the user to settings
                    val checkVal = androidx.core.content.ContextCompat.checkSelfPermission(
                        context,
                        android.Manifest.permission.RECORD_AUDIO
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!checkVal) {
                        try {
                            val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = android.net.Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            android.util.Log.e("VoiceScreen", "Failed opening settings", e)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = "Izinkan Akses Mikrofon",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .testTag("voice_screen")
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // --- Header Status ---
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 24.dp)
            ) {
                Text(
                    text = "VOICE CONVERSATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = Color(0xFFD0BCFF)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = when {
                        isLoading -> "Asisten sedang memproses..."
                        isVoiceActive -> "Mendengarkan percakapan..."
                        else -> "Asisten Suara Nonaktif"
                    },
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            // --- Center Glowing Wave ---
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(240.dp)
            ) {
                if (isVoiceActive) {
                    // Wave background glow rings
                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(Color(0xFFD0BCFF).copy(alpha = 0.15f))
                    )
                    Box(
                        modifier = Modifier
                            .size(110.dp)
                            .scale(pulseScale * 0.85f)
                            .clip(CircleShape)
                            .background(Color(0xFF381E72).copy(alpha = 0.25f))
                    )
                }

                // Central Interactive Button
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    Color(0xFFD0BCFF),
                                    Color(0xFF381E72)
                                )
                            )
                        )
                        .clickable { viewModel.toggleVoiceAssistant() }
                        .testTag("voice_assistant_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isVoiceActive) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = "Toggle Voice Assistant",
                        tint = Color.White,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            // --- Bottom Response Screen log ---
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF25232A)),
                border = BorderStroke(1.dp, Color(0xFF49454F)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speaker status",
                            tint = Color(0xFFD0BCFF),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Respons Terakhir",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD0BCFF)
                        )
                    }
                    Text(
                        text = speechText.ifBlank { "Tekan tombol mikrofon di atas untuk berbicara. Saya dapat melakukan aksi perangkat secara instan melalui suara Anda." },
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        color = Color(0xFFE6E1E5),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(top = 12.dp)
                    )
                }
            }
        }
    }
}
