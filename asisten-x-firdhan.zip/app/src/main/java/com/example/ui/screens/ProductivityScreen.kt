package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.HabitEntity
import com.example.data.database.NoteEntity
import com.example.data.database.ReminderEntity
import com.example.ui.viewmodel.AssistantViewModel

@Composable
fun ProductivityScreen(viewModel: AssistantViewModel) {
    val notes by viewModel.notes.collectAsState()
    val reminders by viewModel.reminders.collectAsState()
    val habits by viewModel.habits.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Notes, 1: Reminders & Habits

    var showAddNoteDialog by remember { mutableStateOf(false) }
    var showAddReminderDialog by remember { mutableStateOf(false) }
    var showAddHabitDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("productivity_screen")
    ) {
        // --- Tab Selection ---
        TabRow(selectedTabIndex = activeTab) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Notes", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Reminders & Habits", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (activeTab == 0) {
                // Notes List
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (notes.isEmpty()) {
                        item {
                            EmptyStateWidget(
                                icon = Icons.Default.NoteAlt,
                                message = "Catatan kosong. Klik '+' untuk menambahkan catatan baru."
                            )
                        }
                    } else {
                        items(notes) { note ->
                            NoteItemCard(note = note, onDelete = { viewModel.deleteNote(note.id) })
                        }
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) } // gap for FAB
                }

                // Add Note FAB
                FloatingActionButton(
                    onClick = { showAddNoteDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(24.dp)
                        .testTag("add_note_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Note")
                }

            } else {
                // Reminders & Habits List
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Reminders Section
                    item {
                        SectionHeaderWithAction(
                            title = "⏰ Jadwal Reminder",
                            onAction = { showAddReminderDialog = true }
                        )
                    }

                    if (reminders.isEmpty()) {
                        item {
                            Text(
                                text = "Tidak ada reminder aktif.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    } else {
                        items(reminders) { reminder ->
                            ReminderItemCard(
                                reminder = reminder,
                                onCheckedChange = { viewModel.toggleReminderCompleted(reminder) },
                                onDelete = { viewModel.deleteReminder(reminder.id) }
                            )
                        }
                    }

                    // Habits Section
                    item {
                        SectionHeaderWithAction(
                            title = "🔥 Habit Tracker",
                            onAction = { showAddHabitDialog = true }
                        )
                    }

                    if (habits.isEmpty()) {
                        item {
                            Text(
                                text = "Belum membuat kebiasaan harian.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    } else {
                        items(habits) { habit ->
                            HabitItemCard(
                                habit = habit,
                                onComplete = { viewModel.completeHabit(habit) },
                                onDelete = { viewModel.deleteHabit(habit.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(40.dp)) }
                }
            }
        }
    }

    // --- Dialogs ---
    if (showAddNoteDialog) {
        var title by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddNoteDialog = false },
            title = { Text("Catatan Baru") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Judul") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Isi Catatan") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 5
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            viewModel.addNote(title, content)
                            showAddNoteDialog = false
                        }
                    }
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNoteDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (showAddReminderDialog) {
        var title by remember { mutableStateOf("") }
        var time by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddReminderDialog = false },
            title = { Text("Buat Reminder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Tugas / Kegiatan") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Waktu (Contoh: 20:00)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank() && time.isNotBlank()) {
                            viewModel.addReminder(title, time)
                            showAddReminderDialog = false
                        }
                    }
                ) {
                    Text("Simpan")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddReminderDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (showAddHabitDialog) {
        var name by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddHabitDialog = false },
            title = { Text("Habit Baru") },
            text = {
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Kebiasaan (Contoh: Minum Air)") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            viewModel.addHabit(name)
                            showAddHabitDialog = false
                        }
                    }
                ) {
                    Text("Buat")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddHabitDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }
}

@Composable
fun SectionHeaderWithAction(
    title: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = onAction) {
            Icon(imageVector = Icons.Default.AddCircle, contentDescription = "Add Item", tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
fun NoteItemCard(
    note: NoteEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF25232A)),
        border = BorderStroke(1.dp, Color(0xFF49454F)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = note.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete note", tint = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = note.content,
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = Color(0xFFE6E1E5)
            )
        }
    }
}

@Composable
fun ReminderItemCard(
    reminder: ReminderEntity,
    onCheckedChange: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF25232A)),
        border = BorderStroke(1.dp, Color(0xFF49454F)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Checkbox(
                    checked = reminder.isCompleted,
                    onCheckedChange = onCheckedChange,
                    colors = CheckboxDefaults.colors(
                        checkedColor = Color(0xFFD0BCFF),
                        checkmarkColor = Color(0xFF381E72)
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = reminder.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (reminder.isCompleted) Color(0xFF938F99) else Color.White,
                        textDecoration = if (reminder.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                    )
                    Text(
                        text = "⏰ Jam ${reminder.time}",
                        fontSize = 11.sp,
                        color = Color(0xFF938F99)
                    )
                }
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete reminder", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
fun HabitItemCard(
    habit: HabitEntity,
    onComplete: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF25232A)),
        border = BorderStroke(1.dp, Color(0xFF49454F)),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = habit.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Daily Streak: ${habit.streak} hari berturut-turut",
                    fontSize = 11.sp,
                    color = Color(0xFF938F99)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onComplete,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFD0BCFF),
                        contentColor = Color(0xFF381E72)
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(text = "Selesai 🔥", fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete habit", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun EmptyStateWidget(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    message: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 60.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "Empty list",
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = message,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
        )
    }
}
