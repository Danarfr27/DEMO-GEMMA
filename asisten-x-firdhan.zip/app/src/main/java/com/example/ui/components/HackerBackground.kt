package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun HackerBackground(modifier: Modifier = Modifier) {
    // 1. efek kedip ambulans, ijo toxic sama item pekat
    val infiniteTransition = rememberInfiniteTransition(label = "ambulance_pulse")
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_progress"
    )

    // buat nampung geseran pas layar di-drag (efek paralaks)
    var dragOffset by remember { mutableStateOf(Offset.Zero) }

    // auto geser pelan biar bg keliatan idup walau lagi diem
    val autoPanX by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 15000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auto_pan_x"
    )

    val autoPanY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auto_pan_y"
    )

    val neonGreen = Color(0xFF39FF14)
    val darkBlack = Color(0xFF000000)

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        // redam dikit biar efek 3D paralaksnya kerasa smooth
                        dragOffset = Offset(
                            x = (dragOffset.x + dragAmount.x * 0.15f).coerceIn(-120f, 120f),
                            y = (dragOffset.y + dragAmount.y * 0.15f).coerceIn(-120f, 120f)
                        )
                    }
                )
            }
    ) {
        // balikin posisi geser ke tengah pelan-pelan pas dilepas
        LaunchedEffect(dragOffset) {
            if (dragOffset != Offset.Zero) {
                animate(
                    initialValue = dragOffset.x,
                    targetValue = 0f,
                    animationSpec = spring(stiffness = Spring.StiffnessVeryLow)
                ) { value, _ ->
                    dragOffset = dragOffset.copy(x = value)
                }
            }
        }
        LaunchedEffect(dragOffset) {
            if (dragOffset != Offset.Zero) {
                animate(
                    initialValue = dragOffset.y,
                    targetValue = 0f,
                    animationSpec = spring(stiffness = Spring.StiffnessVeryLow)
                ) { value, _ ->
                    dragOffset = dragOffset.copy(y = value)
                }
            }
        }

        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // LAYER 1: efek pancaran lampu ambulans ijo toxic kiri kanan bergantian
            // kedip ganti-gantian kiri kanan
            val leftAlpha = sin(pulseProgress * Math.PI).toFloat().coerceIn(0f, 1f) * 0.22f
            val rightAlpha = sin((pulseProgress + 0.5f) * Math.PI).toFloat().coerceIn(0f, 1f) * 0.22f

            // background item pekat
            drawRect(color = darkBlack)

            // cahaya ambulans sebelah kiri
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(neonGreen.copy(alpha = leftAlpha), Color.Transparent),
                    center = Offset(0f, height / 2f),
                    radius = width * 0.8f
                )
            )

            // cahaya ambulans sebelah kanan
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(neonGreen.copy(alpha = rightAlpha), Color.Transparent),
                    center = Offset(width, height / 2f),
                    radius = width * 0.8f
                )
            )

            // LAYER 2: garis-garis grid siber biar kerasa hacker
            val gridSpacing = 64.dp.toPx()
            val offsetX = dragOffset.x + (autoPanX * 0.2f)
            val offsetY = dragOffset.y + (autoPanY * 0.2f)

            // gambar garis grid vertikal pake paralaks
            var x = offsetX % gridSpacing
            while (x < width) {
                if (x >= 0) {
                    drawLine(
                        color = neonGreen.copy(alpha = 0.05f),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                x += gridSpacing
            }

            // gambar garis grid horizontal
            var y = offsetY % gridSpacing
            while (y < height) {
                if (y >= 0) {
                    drawLine(
                        color = neonGreen.copy(alpha = 0.05f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }
                y += gridSpacing
            }

            // LAYER 3: titik-titik node hacker interaktif
            val nodes = listOf(
                Offset(0.15f, 0.2f), Offset(0.35f, 0.45f), Offset(0.55f, 0.15f),
                Offset(0.75f, 0.35f), Offset(0.25f, 0.7f), Offset(0.65f, 0.8f),
                Offset(0.85f, 0.65f), Offset(0.45f, 0.9f)
            )

            nodes.forEachIndexed { index, normalizedPos ->
                // posisi dasar
                val bx = normalizedPos.x * width
                val by = normalizedPos.y * height

                // terapin paralaks layer 3 biar lebih cepet geraknya daripada grid (efek kedalaman)
                val px = bx + dragOffset.x * (1.3f + (index % 3) * 0.2f) + (autoPanX * 0.3f)
                val py = by + dragOffset.y * (1.3f + (index % 3) * 0.2f) + (autoPanY * 0.3f)

                // batesin biar kaga keluar dari layar
                val finalX = px % width
                val finalY = py % height

                val safeX = if (finalX < 0) finalX + width else finalX
                val safeY = if (finalY < 0) finalY + height else finalY

                // bikin titiknya kedip-kedip random
                val nodeAlpha = (0.05f + 0.12f * sin(pulseProgress * Math.PI + index).toFloat().coerceIn(0f, 1f))

                // gambar buletan nodenya
                drawCircle(
                    color = neonGreen.copy(alpha = nodeAlpha),
                    radius = 6.dp.toPx(),
                    center = Offset(safeX, safeY)
                )
                drawCircle(
                    color = neonGreen.copy(alpha = nodeAlpha * 2f),
                    radius = 2.dp.toPx(),
                    center = Offset(safeX, safeY)
                )
            }
        }
    }
}
