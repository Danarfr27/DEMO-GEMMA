package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.AssistantViewModel

@Composable
fun SettingsScreen(viewModel: AssistantViewModel) {
    val themeMode by viewModel.themeMode.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val isFloatingOverlayEnabled by viewModel.isFloatingOverlayEnabled.collectAsState()

    var showClearChatDialog by remember { mutableStateOf(false) }
    var showBackupFeedback by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Theme Configuration ---
        item {
            Text(text = "Tampilan & Tema", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setTheme("dark") }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.DarkMode, contentDescription = "Dark Theme", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "Mode Gelap (Premium Dark)", fontSize = 14.sp)
                        }
                        RadioButton(selected = themeMode == "dark", onClick = { viewModel.setTheme("dark") })
                    }
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setTheme("light") }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.LightMode, contentDescription = "Light Theme", tint = MaterialTheme.colorScheme.secondary)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "Mode Terang (Minimalist Slate)", fontSize = 14.sp)
                        }
                        RadioButton(selected = themeMode == "light", onClick = { viewModel.setTheme("light") })
                    }
                }
            }
        }

        // --- AI Model & Overlay ---
        item {
            Text(text = "Konfigurasi Sistem AI", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Active AI Model
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Mesin Pemrosesan AI", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(text = "Mesin Kecerdasan Buatan Terenkripsi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedModel == "premium",
                            onClick = { viewModel.setModel("premium") },
                            label = { Text("Asisten Premium Online") }
                        )
                        FilterChip(
                            selected = selectedModel == "standard",
                            onClick = { viewModel.setModel("standard") },
                            label = { Text("Asisten Standar Online") }
                        )
                        FilterChip(
                            selected = selectedModel == "pro",
                            onClick = { viewModel.setModel("pro") },
                            label = { Text("Asisten Penalaran Tinggi") }
                        )
                        FilterChip(
                            selected = selectedModel == "local",
                            onClick = { viewModel.setModel("local") },
                            label = { Text("Asisten Lokal Offline") }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val modelDesc = when (selectedModel) {
                        "premium" -> "Asisten Premium Online: Model super cepat dan cerdas dengan kapabilitas multimodal online dan rotator kunci enkripsi."
                        "standard" -> "Asisten Standar Online: Cepat dan efisien untuk tugas percakapan & asisten umum sehari-hari."
                        "pro" -> "Asisten Penalaran Tinggi: Kemampuan penalaran kognitif tingkat tinggi, penyelesaian masalah kompleks, dan pemrograman."
                        "local" -> "Asisten Lokal Offline: Berjalan sepenuhnya offline tanpa internet. Mendukung sandboxing eksekusi kode lokal terenkripsi."
                        else -> "Mesin kustom aktif."
                    }
                    Text(
                        text = modelDesc,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Floating Assistant Bubble switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Floating Assistant Bubble", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text(text = "Tampilkan asisten melayang di atas aplikasi", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                        Switch(
                            checked = isFloatingOverlayEnabled,
                            onCheckedChange = { viewModel.toggleFloatingOverlay() }
                        )
                    }
                }
            }
        }

        // --- Data & Chat Backups ---
        item {
            Text(text = "Manajemen Data & Backup", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Export Backups
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showBackupFeedback = true }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = "Export JSON", tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "Ekspor Riwayat Chat (JSON)", fontSize = 14.sp)
                            Text(text = "Simpan cadangan pesan lokal ke folder Download", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    // Import Backups
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showBackupFeedback = true }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CloudDownload, contentDescription = "Import JSON", tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "Impor Riwayat Chat (JSON)", fontSize = 14.sp)
                            Text(text = "Kembalikan pesan dari file cadangan eksternal", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                    // Clear Chat
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showClearChatDialog = true }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear Chat", tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "Bersihkan Semua Riwayat Percakapan", fontSize = 14.sp, color = MaterialTheme.colorScheme.error)
                            Text(text = "Menghapus permanen log chat lokal dari database", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                        }
                    }
                }
            }
        }

        // --- Developer Section ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Gemma 4 E2B v1.0", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Dibuat khusus untuk kenyamanan produktivitas asisten mobile premium. Menggunakan model kecerdasan buatan canggih untuk pemrosesan asisten lokal berkinerja tinggi.", fontSize = 11.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                }
            }
        }
    }

    // --- Dialogs ---
    if (showClearChatDialog) {
        AlertDialog(
            onDismissRequest = { showClearChatDialog = false },
            title = { Text("Hapus Riwayat Chat?") },
            text = { Text("Tindakan ini akan menghapus seluruh riwayat percakapan Anda dengan asisten Gemma 4 E2B secara permanen dari penyimpanan lokal perangkat.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        viewModel.clearAllChatHistory()
                        showClearChatDialog = false
                    }
                ) {
                    Text("Hapus Permanen", color = MaterialTheme.colorScheme.onError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearChatDialog = false }) {
                    Text("Batal")
                }
            }
        )
    }

    if (showBackupFeedback) {
        AlertDialog(
            onDismissRequest = { showBackupFeedback = false },
            title = { Text("Ekspor / Impor Berhasil") },
            text = { Text("Operasi backup cadangan database selesai diproses secara lokal dan terenkripsi.") },
            confirmButton = {
                Button(onClick = { showBackupFeedback = false }) {
                    Text("OK")
                }
            }
        )
    }
}
