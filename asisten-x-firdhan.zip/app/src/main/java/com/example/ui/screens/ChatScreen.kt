package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.ChatHistoryEntity
import com.example.ui.viewmodel.AssistantViewModel
import kotlinx.coroutines.launch
import java.io.InputStream

@Composable
fun ChatScreen(
    viewModel: AssistantViewModel,
    prefilledText: String? = null
) {
    val chats by viewModel.chatHistory.collectAsState()
    val isLoading by viewModel.isAiLoading.collectAsState()
    val localModelProgress by viewModel.localModelProgress.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var textInput by remember { mutableStateOf(prefilledText ?: "") }
    var selectedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var showCameraPicker by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        try {
            uri?.let {
                val inputStream: InputStream? = context.contentResolver.openInputStream(it)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                selectedBitmap = bitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Scroll to latest message
    LaunchedEffect(chats.size) {
        if (chats.isNotEmpty()) {
            listState.animateScrollToItem(chats.size - 1)
        }
    }

    // Command Suggestions state
    val commands = remember {
        listOf(
            "nyalakan lampu",
            "matikan lampu",
            "buka Kamera",
            "buka WhatsApp",
            "buka Chrome",
            "ingat nama saya Danar Firdhan Roichan",
            "siapa nama saya?",
            "catat beli kopi pagi",
            "ingatkan saya jam 8 malam",
            "ringkas teks",
            "jelaskan gambar"
        )
    }

    val showSuggestions = textInput.startsWith("/")
    val filteredCommands = remember(textInput) {
        if (textInput.startsWith("/")) {
            val query = textInput.removePrefix("/").lowercase()
            commands.filter { it.lowercase().contains(query) }
        } else {
            emptyList()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("chat_screen")
    ) {
        // Floating download progress for offline mode
        localModelProgress?.let { progress ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .align(Alignment.TopCenter)
                    .zIndex(10f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1A30)),
                border = BorderStroke(1.dp, Color(0xFF14B8A6).copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Syncing",
                                tint = Color(0xFF14B8A6),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Menyiapkan Offline Engine...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF14B8A6)
                            )
                        }
                        Text(
                            text = "$progress%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14B8A6)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = progress / 100f,
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF14B8A6),
                        trackColor = Color(0xFF14B8A6).copy(alpha = 0.2f),
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Mengunduh pembungkus sandbox lokal terenkripsi (0-ms)...",
                        fontSize = 10.sp,
                        color = Color.LightGray.copy(alpha = 0.8f)
                    )
                }
            }
        }
        Column(modifier = Modifier.fillMaxSize()) {
            // --- Custom Header with Online/Offline Toggle Button ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isOnline = selectedModel == "premium"
                    Button(
                        onClick = {
                            if (isOnline) {
                                viewModel.setModel("local")
                            } else {
                                viewModel.setModel("premium")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOnline) Color(0xFF14B8A6) else Color(0xFFE53935)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = if (isOnline) "🟢 Online" else "🔴 Offline",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Chat AI",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                
                val modelLabel = when (selectedModel) {
                    "premium" -> "Asisten Premium"
                    "standard" -> "Asisten Standar"
                    "pro" -> "Asisten Penalaran"
                    "local" -> "Asisten Offline"
                    else -> "Mesin Kustom"
                }
                Text(
                    text = modelLabel,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // Chat Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (chats.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 48.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChatBubbleOutline,
                                contentDescription = "Empty Chat",
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Hai saya Gemma 4 E2B, asisten offline pintar kamu. Ada yang bisa saya bantu?",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                            )
                            Text(
                                text = "Ketik '/' untuk daftar perintah cepat offline.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                            )
                        }
                    }
                } else {
                    items(chats) { chat ->
                        ChatBubbleRow(chat)
                    }
                }

                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Asisten sedang memproses...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }

            // Preview selected image
            AnimatedVisibility(visible = selectedBitmap != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        selectedBitmap?.let {
                            Image(
                                bitmap = it.asImageBitmap(),
                                contentDescription = "Attached Image",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Gambar siap dikirim",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { selectedBitmap = null }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Cancel attachment")
                    }
                }
            }

            // Input Row & Palette Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(8.dp)
            ) {
                Column {
                    // Suggestions popup
                    AnimatedVisibility(visible = showSuggestions && filteredCommands.isNotEmpty()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(4.dp)) {
                                Text(
                                    text = "⚡ Perintah Offline Gemma 4 E2B",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(8.dp)
                                )
                                Divider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
                                filteredCommands.forEach { cmd ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                textInput = cmd
                                            }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.OfflineBolt,
                                            contentDescription = "Command",
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = "/$cmd", fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Input Text Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(28.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)), RoundedCornerShape(28.dp))
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showCameraPicker = true },
                            modifier = Modifier.testTag("attachment_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Camera attachment",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier.testTag("gallery_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Gallery attachment",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        TextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("Ketik pesan atau / untuk aksi...", fontSize = 14.sp, color = MaterialTheme.colorScheme.outline) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("message_input_field"),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            maxLines = 4
                        )

                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .clickable {
                                    if (textInput.isNotBlank() || selectedBitmap != null) {
                                        viewModel.sendChatMessage(textInput, selectedBitmap)
                                        textInput = ""
                                        selectedBitmap = null
                                    }
                                }
                                .testTag("send_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send message",
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Camera Picker Dialog simulation
        if (showCameraPicker) {
            AlertDialog(
                onDismissRequest = { showCameraPicker = false },
                title = { Text("Simulasi Kamera Vision") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Emulator streaming tidak memiliki akses kamera fisik. Pilih salah satu mock gambar uji untuk dianalisis Gemma 4 E2B:")
                        Button(
                            onClick = {
                                selectedBitmap = createMockBitmap(1)
                                showCameraPicker = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("📄 Kotlin Source Code Sample")
                        }
                        Button(
                            onClick = {
                                selectedBitmap = createMockBitmap(2)
                                showCameraPicker = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🥗 Makanan Sehat Seimbang (Nutrisi)")
                        }
                        Button(
                            onClick = {
                                selectedBitmap = createMockBitmap(3)
                                showCameraPicker = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🛋️ Desain Interior Kamar Premium")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showCameraPicker = false }) {
                        Text("Batal")
                    }
                }
            )
        }
    }
}

@Composable
fun ChatBubbleRow(chat: ChatHistoryEntity) {
    val isUser = chat.sender == "user"
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Column(
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
            modifier = Modifier.fillMaxWidth(0.85f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
            ) {
                if (!isUser) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("G", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = if (isUser) "Anda" else "Gemma AI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                modifier = Modifier.testTag("chat_bubble_${chat.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    if (chat.imagePath != null) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Gambar",
                            tint = if (isUser) Color.Black else MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(64.dp)
                                .padding(bottom = 4.dp)
                        )
                    }
                    Text(
                        text = chat.message,
                        fontSize = 14.sp,
                        color = if (isUser) Color.Black else MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val context = LocalContext.current
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Chat Message", chat.message)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Teks berhasil disalin!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Salin Teks",
                                tint = (if (isUser) Color.Black else MaterialTheme.colorScheme.primary).copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Generates a colored bitmap for simulation
private fun createMockBitmap(type: Int): Bitmap {
    val conf = Bitmap.Config.ARGB_8888
    val bmp = Bitmap.createBitmap(150, 150, conf)
    val canvas = android.graphics.Canvas(bmp)
    val paint = android.graphics.Paint()
    when (type) {
        1 -> { // Kotlin Code
            paint.color = android.graphics.Color.DKGRAY
            canvas.drawRect(0f, 0f, 150f, 150f, paint)
            paint.color = android.graphics.Color.CYAN
            canvas.drawRect(10f, 10f, 100f, 20f, paint)
            canvas.drawRect(20f, 30f, 120f, 40f, paint)
        }
        2 -> { // Healthy food
            paint.color = android.graphics.Color.GREEN
            canvas.drawRect(0f, 0f, 150f, 150f, paint)
            paint.color = android.graphics.Color.RED
            canvas.drawCircle(75f, 75f, 30f, paint)
        }
        3 -> { // Interior
            paint.color = android.graphics.Color.BLUE
            canvas.drawRect(0f, 0f, 150f, 150f, paint)
            paint.color = android.graphics.Color.YELLOW
            canvas.drawRect(30f, 50f, 120f, 130f, paint)
        }
    }
    return bmp
}
