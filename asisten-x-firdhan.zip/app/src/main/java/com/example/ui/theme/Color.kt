package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hacker Cyber Security Theme (Black & Neon Light Green)
val HackerDarkBg = Color(0xFF000000)
val HackerCardDark = Color(0xFF080C08)
val HackerPrimary = Color(0xFF39FF14) // Neon light green (hacker lime)
val HackerOnPrimary = Color(0xFF000000) // Pitch black on neon green for supreme readability
val HackerSecondary = Color(0xFF00E676) // Medium toxic green
val HackerMutedContainer = Color(0xFF111A11)
val HackerMutedText = Color(0xFF81C784)
val HackerActiveGreen = Color(0xFF39FF14)
val HackerBottomBarBg = Color(0xFF030503)

// Professional Polish Design Palette (Material 3 Dark Slate)
val ProfessionalDarkBg = HackerDarkBg
val ProfessionalCardDark = HackerCardDark
val ProfessionalPrimary = HackerPrimary
val ProfessionalOnPrimary = HackerOnPrimary
val ProfessionalSecondary = HackerSecondary
val ProfessionalMutedContainer = HackerMutedContainer
val ProfessionalMutedText = HackerMutedText
val ProfessionalActiveGreen = HackerActiveGreen
val ProfessionalBottomBarBg = HackerBottomBarBg

// Existing legacy variables for backwards compatibility
val SpaceDarkBg = ProfessionalDarkBg
val SpaceCardDark = ProfessionalCardDark
val PrimaryGlowingPurple = ProfessionalPrimary
val AccentAuroraTeal = ProfessionalSecondary
val GlowPink = Color(0xFF39FF14)
val SlateGrayText = ProfessionalMutedText

// Premium Light Mode Palettes (Clean Minimal Slate)
val MinimalLightBg = Color(0xFF000000) // In hacker theme, even light mode can be cyber-focused or pure black
val MinimalCardLight = Color(0xFF080C08)
val PrimaryIndigo = Color(0xFF00E676)
val AccentTeal = Color(0xFF111A11)
val NeutralGrayText = Color(0xFF81C784)

