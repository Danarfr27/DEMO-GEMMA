package com.example.ai

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .addInterceptor(loggingInterceptor)
        .build()

    private val DEFAULT_KEYS = listOf(
        "AQ.Ab8RN6LYTSYd7yvEzcgz2MdvYXlLCzraUAN9RESYF3mJ2lQAjA",
        "AIzaSyDwjIjm8Ni-GrtoebjXbmsfkPK20_-xUuw",
        "AQ.Ab8RN6IbrsPhq5mknZeaHGIw_PDu3GBf3FR08H9IzgE3Q9yewA",
        "AQ.Ab8RN6I902lpuT2xS8RM3eUD5o6xyB3iSh83uWjgDEiuniI33A",
        "AIzaSyA7J460sTUHb_5FFj-QuwSXG3eMhikwYnU",
        "AQ.Ab8RN6I4GL4ihVDbuCAohIF6d3igjnM7G0vGpWJljFpscge3PA",
        "AIzaSyAmC2YZh1kTt-92Ix6WhS_-ResoBLmIJyw",
        "AQ.Ab8RN6InXrUhnlF4TfWNQQ53H27Nspesv3x6Q_6vL_HKq1ay0w",
        "AQ.Ab8RN6IS480MsccuxpndBuJMyPeT9QXdsHW9nCszLeEycorBJA",
        "AQ.Ab8RN6IwKHiOuYt6R914bWvAEZatGwl70AF468JH8KeAvYFteQ",
        "AQ.Ab8RN6KsIc-oAQN22zQgzXsS8cQBKVxkCQsryGpZj1rWGpf9Ig",
        "AQ.Ab8RN6L1BkgJWbARSYA-XN3PxD-Qz4vhv6spo3_dOkE8yxRQ4w",
        "AQ.Ab8RN6Lw-yGeDMTpCBxepBCIyOUCPlCGy4nWBl07l4NmeHhRjw",
        "AQ.Ab8RN6LazAzH-XsbTCOAlGC5ZsGeWVrN_Yvd56e9MBuathL8Ew",
        "AQ.Ab8RN6I0NWpNyKPlnbsZYQkr92wRaz-iw88R0k8EYER0FWqSgQ",
        "AQ.Ab8RN6KSIkF723G4l4MdCyoxB8xVLdP9Y845BclxEveDBCi8Xg",
        "AQ.Ab8RN6It12tQuxnBOPl08P7F6vFNtotnCWX9v09nM4bU1FmRnA"
    )
    private var currentKeyIndex = 0

    val apiService: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApiService::class.java)
    }

    fun getApiKey(): String {
        val buildConfigKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }
        val keys = if (buildConfigKey.isNotEmpty() && !buildConfigKey.startsWith("TODO")) {
            listOf(buildConfigKey) + DEFAULT_KEYS
        } else {
            DEFAULT_KEYS
        }
        val key = keys[currentKeyIndex]
        currentKeyIndex = (currentKeyIndex + 1) % keys.size
        return key
    }
}
