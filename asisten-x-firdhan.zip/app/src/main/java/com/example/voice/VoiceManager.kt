package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class VoiceManager(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var utteranceCallback: (() -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error instantiating TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val indonesian = Locale("id", "ID")
            val result = tts?.setLanguage(indonesian)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to English
                tts?.setLanguage(Locale.US)
                Log.e("VoiceManager", "Bahasa Indonesia tidak didukung, beralih ke Bahasa Inggris.")
            } else {
                Log.d("VoiceManager", "TextToSpeech siap dengan Bahasa Indonesia.")
            }
            
            // --- Cute Anime Voice Settings ---
            // Higher pitch makes it sound like a cute/funny female anime character
            tts?.setPitch(1.35f)
            // Slightly faster speech rate for cute dynamic speaking style
            tts?.setSpeechRate(1.05f)

            // Try to set female voice if available
            try {
                val voices = tts?.voices
                if (!voices.isNullOrEmpty()) {
                    var selectedVoice = voices.find { voice ->
                        val name = voice.name.lowercase()
                        voice.locale.language == "id" && (
                            name.contains("female") || 
                            name.contains("-f-") || 
                            name.contains("dfg") || 
                            name.contains("dfz") || 
                            name.contains("lh") ||
                            name.contains("fem")
                        )
                    }
                    if (selectedVoice == null) {
                        selectedVoice = voices.find { voice ->
                            voice.locale.language == "id"
                        }
                    }
                    if (selectedVoice == null) {
                        selectedVoice = voices.find { voice ->
                            val name = voice.name.lowercase()
                            name.contains("female") || name.contains("-f-") || name.contains("lh") || name.contains("fem")
                        }
                    }
                    if (selectedVoice != null) {
                        tts?.voice = selectedVoice
                        Log.d("VoiceManager", "Selected voice: ${selectedVoice.name}")
                    }
                }
            } catch (e: Exception) {
                Log.e("VoiceManager", "Error choosing female voice: ${e.message}")
            }
            
            try {
                tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            utteranceCallback?.invoke()
                            utteranceCallback = null
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            utteranceCallback?.invoke()
                            utteranceCallback = null
                        }
                    }
                })
            } catch (e: Exception) {
                Log.e("VoiceManager", "Error setting utterance progress listener", e)
            }
            
            isInitialized = true
        } else {
            Log.e("VoiceManager", "Gagal menginisialisasi TextToSpeech.")
        }
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.e("VoiceManager", "Error destroying speech recognizer", e)
        }
    }

    fun speak(text: String, onComplete: () -> Unit = {}) {
        // Clean symbols like * or ** from speech so TTS does not say "star star" or "bintang"
        val cleanText = text
            .replace("**", "")
            .replace("*", "")
            .replace("`", "")
            .replace("#", "")
            .replace("_", "")
            .trim()

        if (cleanText.isBlank()) {
            onComplete()
            return
        }

        if (isInitialized && tts != null) {
            try {
                utteranceCallback = onComplete
                val params = Bundle().apply {
                    putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "FirdhanTTS")
                }
                tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, params, "FirdhanTTS")
            } catch (e: Exception) {
                Log.e("VoiceManager", "Error playing speak", e)
                onComplete()
            }
        } else {
            Log.w("VoiceManager", "TTS belum siap.")
            onComplete()
        }
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onPartialResult: (String) -> Unit = {}
    ) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                destroyRecognizer()
                
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
                
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "id-ID")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }

                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        Log.d("VoiceManager", "Ready for speech")
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        val message = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                            SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissions missing"
                            SpeechRecognizer.ERROR_NETWORK -> "Network error"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech match"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy"
                            SpeechRecognizer.ERROR_SERVER -> "Server error"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech input timeout"
                            else -> "Unknown speech error"
                        }
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            onError(message)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                onResult(matches[0])
                            }
                        } else {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                onError("No speech matched")
                            }
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            android.os.Handler(android.os.Looper.getMainLooper()).post {
                                onPartialResult(matches[0])
                            }
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e("VoiceManager", "Error starting listening", e)
                onError(e.localizedMessage ?: "Gagal memulai perekaman.")
            }
        }
    }

    fun stopListening() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            destroyRecognizer()
        }
    }

    fun stop() {
        tts?.stop()
        stopListening()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        stopListening()
    }
}
