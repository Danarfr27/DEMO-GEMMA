package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.*
import com.example.ui.theme.AccentAuroraTeal
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PrimaryGlowingPurple
import com.example.ui.viewmodel.AssistantViewModel
import com.example.ui.viewmodel.AssistantViewModelFactory
import com.example.ui.components.HackerBackground
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AssistantApplication
        val viewModelFactory = AssistantViewModelFactory(app)
        val viewModel = ViewModelProvider(this, viewModelFactory)[AssistantViewModel::class.java]

        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            val isDark = when (themeMode) {
                "light" -> false
                "dark" -> true
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }

            MyApplicationTheme(darkTheme = isDark) {
                MainAppLayout(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppLayout(viewModel: AssistantViewModel) {
    val activeTab by viewModel.currentActiveTab.collectAsState()
    val isFloatingOverlayEnabled by viewModel.isFloatingOverlayEnabled.collectAsState()

    var showQuickSheet by remember { mutableStateOf(false) }
    var prefilledChatText by remember { mutableStateOf<String?>(null) }

    // Floating Bubble drag offset state
    var bubbleOffsetX by remember { mutableStateOf(0f) }
    var bubbleOffsetY by remember { mutableStateOf(0f) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTab == "dashboard",
                    onClick = { viewModel.setTab("dashboard") },
                    icon = { Icon(imageVector = Icons.Default.Dashboard, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = activeTab == "chat",
                    onClick = {
                        prefilledChatText = null
                        viewModel.setTab("chat")
                    },
                    icon = { Icon(imageVector = Icons.Default.ChatBubble, contentDescription = "Chat") },
                    label = { Text("Chat AI", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_chat")
                )
                NavigationBarItem(
                    selected = activeTab == "voice",
                    onClick = { viewModel.setTab("voice") },
                    icon = { Icon(imageVector = Icons.Default.Mic, contentDescription = "Voice") },
                    label = { Text("Voice", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_voice")
                )
                NavigationBarItem(
                    selected = activeTab == "productivity",
                    onClick = { viewModel.setTab("productivity") },
                    icon = { Icon(imageVector = Icons.Default.Assignment, contentDescription = "Productivity") },
                    label = { Text("Productivity", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_productivity")
                )
                NavigationBarItem(
                    selected = activeTab == "settings",
                    onClick = { viewModel.setTab("settings") },
                    icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 11.sp) },
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Animated hacker parallax background with sweeping ambulance green-black glow
            HackerBackground()

            // Screen switcher
            when (activeTab) {
                "dashboard" -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { prefill ->
                        prefilledChatText = prefill
                        viewModel.setTab("chat")
                    }
                )
                "chat" -> ChatScreen(
                    viewModel = viewModel,
                    prefilledText = prefilledChatText
                )
                "voice" -> VoiceScreen(
                    viewModel = viewModel
                )
                "productivity" -> ProductivityScreen(
                    viewModel = viewModel
                )
                "settings" -> SettingsScreen(
                    viewModel = viewModel
                )
            }

            // --- In-App Draggable Glowing Floating Assistant Bubble ---
            AnimatedVisibility(
                visible = isFloatingOverlayEnabled,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .offset { IntOffset(bubbleOffsetX.roundToInt(), bubbleOffsetY.roundToInt()) }
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                bubbleOffsetX += dragAmount.x
                                bubbleOffsetY += dragAmount.y
                            }
                        }
                        .size(64.dp)
                        .align(Alignment.CenterEnd)
                        .padding(8.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    PrimaryGlowingPurple,
                                    AccentAuroraTeal
                                )
                            )
                        )
                        .clickable { showQuickSheet = true }
                        .testTag("floating_assistant_bubble"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SupportAgent,
                        contentDescription = "Gemma 4 E2B Floating Assistant",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // --- Quick Access Assistant Bottom Sheet ---
            if (showQuickSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showQuickSheet = false },
                    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Gemma 4 E2B Quick Assistant",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Pilih pintasan aksi cepat untuk berinteraksi bersama asisten personal Anda secara langsung.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    showQuickSheet = false
                                    viewModel.setTab("chat")
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Chat, contentDescription = "Chat")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Chat AI", fontSize = 12.sp)
                            }
                            Button(
                                onClick = {
                                    showQuickSheet = false
                                    viewModel.setTab("voice")
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = "Voice")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Voice AI", fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
