package com.example

import android.app.Application
import com.example.data.database.AppDatabase
import com.example.data.repository.AssistantRepository

class AssistantApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val repository: AssistantRepository by lazy { AssistantRepository(database.assistantDao()) }

    override fun onCreate() {
        super.onCreate()
    }
}
