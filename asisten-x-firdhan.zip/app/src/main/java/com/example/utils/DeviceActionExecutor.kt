package com.example.utils

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import com.example.data.database.NoteEntity
import com.example.data.database.ReminderEntity
import com.example.data.repository.AssistantRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ActionResponse(
    val success: Boolean,
    val feedbackMessage: String
)

class DeviceActionExecutor(
    private val context: Context,
    private val repository: AssistantRepository
) {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    suspend fun executeIntentJson(jsonString: String): ActionResponse = withContext(Dispatchers.IO) {
        try {
            // Trim and clean JSON string from markdown blocks if any
            val cleanJson = jsonString.trim()
                .removePrefix("```json")
                .removeSuffix("```")
                .trim()

            val adapter = moshi.adapter(Map::class.java)
            val intentMap = adapter.fromJson(cleanJson) ?: return@withContext ActionResponse(false, "Format intent tidak valid.")

            val intent = intentMap["intent"]?.toString() ?: return@withContext ActionResponse(false, "Tidak ada field 'intent'.")

            return@withContext when (intent) {
                "turn_flashlight" -> {
                    val state = intentMap["state"]?.toString() ?: "on"
                    toggleFlashlight(state == "on" || state == "true")
                }
                "open_app" -> {
                    val app = intentMap["app"]?.toString() ?: ""
                    openAppByName(app)
                }
                "toggle_wifi" -> {
                    openSystemSetting(Settings.ACTION_WIFI_SETTINGS, "WiFi")
                }
                "toggle_bluetooth" -> {
                    openSystemSetting(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth")
                }
                "open_settings" -> {
                    openSystemSetting(Settings.ACTION_SETTINGS, "Pengaturan")
                }
                "make_call" -> {
                    val phoneNumber = intentMap["phoneNumber"]?.toString() ?: ""
                    dialPhoneNumber(phoneNumber)
                }
                "send_sms" -> {
                    val phoneNumber = intentMap["phoneNumber"]?.toString() ?: ""
                    val message = intentMap["message"]?.toString() ?: ""
                    sendSMS(phoneNumber, message)
                }
                "open_maps" -> {
                    val query = intentMap["query"]?.toString() ?: ""
                    openMapsNavigation(query)
                }
                "save_memory" -> {
                    val key = intentMap["key"]?.toString() ?: ""
                    val value = intentMap["value"]?.toString() ?: ""
                    if (key.isNotEmpty() && value.isNotEmpty()) {
                        repository.insertMemory(key, value)
                        ActionResponse(true, "Ingatan disimpan: $key = $value")
                    } else {
                        ActionResponse(false, "Gagal menyimpan ingatan, key/value kosong.")
                    }
                }
                "create_reminder" -> {
                    val title = intentMap["title"]?.toString() ?: "Reminder"
                    val time = intentMap["time"]?.toString() ?: "12:00"
                    repository.insertReminder(ReminderEntity(title = title, time = time))
                    ActionResponse(true, "Reminder berhasil dibuat: '$title' pada jam $time")
                }
                "create_note" -> {
                    val title = intentMap["title"]?.toString() ?: "Catatan Baru"
                    val content = intentMap["content"]?.toString() ?: ""
                    repository.insertNote(NoteEntity(title = title, content = content))
                    ActionResponse(true, "Catatan berhasil disimpan: '$title'")
                }
                "lock_screen" -> {
                    ActionResponse(true, "Fitur Mengunci Layar memerlukan hak administrator perangkat. Mengarahkan Anda ke pengaturan layar kunci.")
                }
                else -> {
                    ActionResponse(false, "Aksi '$intent' belum didukung.")
                }
            }
        } catch (e: Exception) {
            ActionResponse(false, "Gagal menjalankan perintah: ${e.localizedMessage}")
        }
    }

    private fun toggleFlashlight(turnOn: Boolean): ActionResponse {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, turnOn)
                ActionResponse(true, if (turnOn) "Lampu senter dinyalakan!" else "Lampu senter dimatikan!")
            } else {
                ActionResponse(false, "Senter tidak ditemukan pada perangkat.")
            }
        } catch (e: Exception) {
            ActionResponse(false, "Senter tidak dapat diakses (sedang digunakan aplikasi lain atau versi Android tidak mendukung direct-control).")
        }
    }

    private fun openAppByName(appName: String): ActionResponse {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(0)

        // Clean query: remove "buka ", spaces, and lowercase it
        val cleanAppName = appName.lowercase()
            .replace("buka", "")
            .replace("buka aplikasi", "")
            .trim()

        var targetPackage: String? = null

        when {
            // WhatsApp aliases
            cleanAppName.contains("whatsapp") || cleanAppName == "wa" || cleanAppName.contains("wasap") || 
            cleanAppName.contains("watsap") || cleanAppName.contains("whasap") || cleanAppName.contains("washap") ||
            cleanAppName.contains("watsapp") -> targetPackage = "com.whatsapp"

            // YouTube aliases
            cleanAppName.contains("youtube") || cleanAppName == "yt" || cleanAppName.contains("yutub") || 
            cleanAppName.contains("youtub") || cleanAppName.contains("yutup") -> targetPackage = "com.google.android.youtube"

            // Chrome aliases
            cleanAppName.contains("chrome") || cleanAppName.contains("krom") || cleanAppName.contains("gugl") || 
            cleanAppName.contains("gugel") || cleanAppName.contains("browser") || cleanAppName.contains("google") ||
            cleanAppName.contains("gogele") -> targetPackage = "com.android.chrome"

            // Spotify aliases
            cleanAppName.contains("spotify") || cleanAppName == "spoti" || cleanAppName.contains("spotifi") || 
            cleanAppName.contains("music") || cleanAppName.contains("musik") || cleanAppName.contains("lagu") -> targetPackage = "com.spotify.music"

            // TikTok aliases
            cleanAppName.contains("tiktok") || cleanAppName.contains("tik tok") || cleanAppName == "tt" -> targetPackage = "com.zhiliaoapp.musically"

            // Instagram aliases
            cleanAppName.contains("instagram") || cleanAppName == "ig" || cleanAppName.contains("insta") || 
            cleanAppName.contains("instgrm") -> targetPackage = "com.instagram.android"

            // Facebook aliases
            cleanAppName.contains("facebook") || cleanAppName == "fb" || cleanAppName.contains("pesbuk") || 
            cleanAppName.contains("feisbuk") -> targetPackage = "com.facebook.katana"

            // Camera aliases
            cleanAppName.contains("camera") || cleanAppName.contains("kamera") || cleanAppName.contains("foto") || 
            cleanAppName.contains("potret") || cleanAppName == "cam" || cleanAppName.contains("kemra") -> {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return ActionResponse(true, "Membuka Kamera...")
                }
            }
        }

        if (targetPackage != null) {
            val launchIntent = pm.getLaunchIntentForPackage(targetPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionResponse(true, "Membuka $appName...")
            }
        }

        // Broad fuzzy search over installed packages
        for (appInfo in packages) {
            val label = pm.getApplicationLabel(appInfo).toString().lowercase()
            if (label.contains(cleanAppName) || cleanAppName.contains(label)) {
                val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ActionResponse(true, "Membuka ${pm.getApplicationLabel(appInfo)}...")
                }
            }
        }

        // Typo-tolerant similarity match using Levenshtein distance
        var bestAppInfo: android.content.pm.ApplicationInfo? = null
        var bestScore = 0.0
        for (appInfo in packages) {
            val label = pm.getApplicationLabel(appInfo).toString().lowercase()
            val score = getSimilarity(label, cleanAppName)
            if (score > 0.55 && score > bestScore) {
                bestScore = score
                bestAppInfo = appInfo
            }
        }
        if (bestAppInfo != null) {
            val launchIntent = pm.getLaunchIntentForPackage(bestAppInfo.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionResponse(true, "Membuka ${pm.getApplicationLabel(bestAppInfo)}...")
            }
        }

        // If not found, search Google Play Store or trigger default web search
        return try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$cleanAppName")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
            ActionResponse(true, "$appName tidak terpasang di perangkat. Mengarahkan Anda ke Play Store.")
        } catch (e: Exception) {
            ActionResponse(false, "Aplikasi $appName tidak ditemukan.")
        }
    }

    private fun getSimilarity(s1: String, s2: String): Double {
        val longer = if (s1.length > s2.length) s1 else s2
        val shorter = if (s1.length > s2.length) s2 else s1
        val longerLength = longer.length
        if (longerLength == 0) return 1.0
        return (longerLength - editDistance(longer, shorter)) / longerLength.toDouble()
    }

    private fun editDistance(s1: String, s2: String): Int {
        val costs = IntArray(s2.length + 1)
        for (i in 0..s1.length) {
            var lastValue = i
            for (j in 0..s2.length) {
                if (i == 0) {
                    costs[j] = j
                } else {
                    if (j > 0) {
                        var newValue = costs[j - 1]
                        if (s1[i - 1] != s2[j - 1]) {
                            newValue = minOf(newValue, lastValue, costs[j]) + 1
                        }
                        costs[j - 1] = lastValue
                        lastValue = newValue
                    }
                }
            }
            if (i > 0) costs[s2.length] = lastValue
        }
        return costs[s2.length]
    }

    private fun openSystemSetting(action: String, settingName: String): ActionResponse {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResponse(true, "Membuka pengaturan $settingName...")
        } catch (e: Exception) {
            ActionResponse(false, "Gagal membuka pengaturan $settingName.")
        }
    }

    private fun dialPhoneNumber(number: String): ActionResponse {
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResponse(true, "Menghubungi nomor $number...")
        } catch (e: Exception) {
            ActionResponse(false, "Gagal melakukan panggilan.")
        }
    }

    private fun sendSMS(number: String, message: String): ActionResponse {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResponse(true, "Menyiapkan SMS untuk nomor $number...")
        } catch (e: Exception) {
            ActionResponse(false, "Gagal menyiapkan SMS.")
        }
    }

    private fun openMapsNavigation(query: String): ActionResponse {
        return try {
            val uriStr = if (query.isNotEmpty()) "geo:0,0?q=${Uri.encode(query)}" else "geo:0,0"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionResponse(true, "Membuka peta pencarian: '$query'...")
        } catch (e: Exception) {
            ActionResponse(false, "Gagal membuka aplikasi navigasi peta.")
        }
    }
}
